# Movie News Website

A modern, production-ready movie news website built with Next.js 14, Tailwind CSS, and Supabase.

## Features

- 🎬 Latest movie news from Hollywood, Bollywood, and Web Series
- 📝 Full-featured admin panel for content management
- 🔍 Advanced search functionality
- 🌓 Dark/Light mode toggle
- 📱 Fully responsive design
- ⚡ Optimized performance
- 🔒 Secure authentication

## Tech Stack

- **Frontend**: Next.js 14 (App Router)
- **Styling**: Tailwind CSS
- **Database**: Supabase (PostgreSQL)
- **Authentication**: JWT
- **Hosting**: Vercel-ready

## Getting Started

### Prerequisites

- Node.js 18+ installed
- Supabase account
- npm or yarn

### Installation

1. Clone the repository
2. Install dependencies:

```bash
npm install
```

3. Set up environment variables:

Create a `.env.local` file in the root directory and add:

```env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key
JWT_SECRET=your_jwt_secret_key_here
ADMIN_EMAIL=admin@movienews.com
ADMIN_PASSWORD=your_secure_password
NEXT_PUBLIC_SITE_URL=http://localhost:3000
NEXT_PUBLIC_SITE_NAME=Movie News Hub
```

4. Set up the database:

- Go to your Supabase project
- Navigate to SQL Editor
- Run the SQL script from `database/schema.sql`

5. Create an admin user:

Run this SQL in Supabase SQL Editor (replace with your hashed password):

```sql
INSERT INTO admins (email, password_hash)
VALUES ('admin@movienews.com', 'your_bcrypt_hashed_password');
```

To generate a bcrypt hash, you can use online tools or Node.js:

```javascript
const bcrypt = require('bcryptjs');
const hash = bcrypt.hashSync('your_password', 10);
console.log(hash);
```

### Development

Run the development server:

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Production Build

```bash
npm run build
npm run start
```

## Deployment

### Vercel

1. Push your code to GitHub
2. Import the project in Vercel
3. Add environment variables in Vercel dashboard
4. Deploy

## Project Structure

```
movie-news-website/
├── app/
│   ├── admin/
│   │   ├── dashboard/
│   │   └── login/
│   ├── api/
│   │   ├── admin/
│   │   └── articles/
│   ├── article/
│   ├── category/
│   ├── search/
│   ├── layout.tsx
│   ├── page.tsx
│   └── globals.css
├── components/
│   ├── ArticleCard.tsx
│   ├── ArticleEditor.tsx
│   ├── CategoryFilter.tsx
│   ├── Footer.tsx
│   ├── Hero.tsx
│   ├── Navbar.tsx
│   ├── SearchBar.tsx
│   └── ThemeProvider.tsx
├── lib/
│   ├── auth.ts
│   ├── supabase.ts
│   ├── types.ts
│   └── utils.ts
├── database/
│   └── schema.sql
├── package.json
├── next.config.js
├── tailwind.config.ts
└── tsconfig.json
```

## Admin Panel

Access the admin panel at `/admin/login`

Default credentials (change these in production):
- Email: admin@movienews.com
- Password: (set during setup)

## License

MIT
